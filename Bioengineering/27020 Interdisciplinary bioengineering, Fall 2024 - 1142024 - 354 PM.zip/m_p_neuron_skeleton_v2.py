import numpy as np
import math
import matplotlib.pyplot as plt

class mp_neuron():
	def __init__(self):
		# initialize the variables
		
	def sum_input(self,inputs=[]):
		# sum of the input values
	
		return self.input_total

	def set_theta(self,gate_type):
		self.gate_type = gate_type
		if self.gate_type == '':
			self.theta = #fill in relevant threshold		
		if self.gate_type == '':
			self.theta = #fill in relevant threshold	(Hint: do you need to manually update this based on number of inputs or is there a variable that you can use here?)
		return self.theta

	def compare_threshold(self,input_sum):
		# Implement the Threshold function
		
		#If the inputs are less than theta, 

		#If the inputs are greater than theta

		return self.y # return the output

#Create MP neuron
mp = mp_neuron()		

#User updated values
input_values = []		#Try changing these values to test different scenarios, add or remove inputs - how would that change theta?
gate_type = ''			#Fill in different valid gate types to test

#Run network
input_sum = mp.sum_input(input_values)
mp.set_theta(gate_type)
output = mp.compare_threshold(input_sum)
print ("The output of the network is:")
print(output)

